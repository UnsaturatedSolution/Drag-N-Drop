/* tslint:disable */
require("./DragAndDrop.module.css");
const styles = {
  dropboxContainer: 'dropboxContainer_b1299517',
  fileUploadBtn: 'fileUploadBtn_b1299517',
  attachmentLabelSection: 'attachmentLabelSection_b1299517',
  existingAttachmentsList: 'existingAttachmentsList_b1299517',
  attachmentLabel: 'attachmentLabel_b1299517',
  attachmentList: 'attachmentList_b1299517',
  attachedItem: 'attachedItem_b1299517',
  attachmentDeleteIcon: 'attachmentDeleteIcon_b1299517'
};

export default styles;
/* tslint:enable */